MORPH-DA Anonymous Supplementary Material
==========================================

This package contains:

  task_specs/          YAML task specifications (101 tasks)
  morphda/data/        Seeded data generators (8 scenarios)
  morphda/relations/   Metamorphic relation implementations (20+ relations)
  morphda/evaluation/  Metrics, bootstrap CI, McNemar test implementations
  scripts/             Experiment runner scripts
  results/             Aggregate result tables and JSON statistics
  logs/                De-identified experiment logs

Author-identifying information has been omitted for double-blind review.
Repository links will be provided in the camera-ready version.

Contents verified consistent with paper v0.5 (Aug 2026).
All results from runs/ are pre-computed; no API keys are included.
